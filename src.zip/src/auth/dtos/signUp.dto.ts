export class SignupDto {
    email: string;
    password: string;
    phone: string;
}